<?php
class Mirasvit_Fpc_Helper_Code extends Mirasvit_MstCore_Helper_Code
{
    protected $k = "5C0VXEOSWL";
    protected $s = "FPC";
    protected $l = "19297";
    protected $v = "1.0.10";
    protected $b = "566";
    protected $d = "sizzix.com";
}
