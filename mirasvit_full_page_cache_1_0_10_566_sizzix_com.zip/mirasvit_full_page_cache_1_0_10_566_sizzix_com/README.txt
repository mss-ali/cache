Carefully follow the manual for installation, configuration, upgrading and removing the extension from your store https://mirasvit.com/doc/fpc/1.0.10/

You have a free support period till Jun 24, 2016. If you need a help, please, contact our support team https://mirasvit.com/support/.
